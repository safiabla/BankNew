package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utilities.Driver;

public class MainPage {

    public MainPage(){
        PageFactory.initElements (Driver.getDriver (),this);
    }

    @FindBy(xpath = "//img[@alt='User Avatar']/..")
    public WebElement userPicture;

    @FindBy(xpath = "//i[@class='fa fa-power -off']")
    public WebElement logOutButton;

    public void logOutFromMainPage(){
        userPicture.click ();
        logOutButton.click ();
    }


    @FindBy(id = "withdraw-menu-item")
    public WebElement withDrawButton;
}
